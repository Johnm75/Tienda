package com.example.tienda.screens.login

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun LoginScreen() {
    Text(text = "Pantalla de Inicio de Sesión")
    // Agrega el resto de los componentes para la pantalla de inicio de sesión aquí
}
