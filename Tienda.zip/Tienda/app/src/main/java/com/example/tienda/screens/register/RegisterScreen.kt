package com.example.tienda.screens.register

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun RegisterScreen() {
    Text(text = "Pantalla de Registro")
    // Agrega el resto de los componentes para la pantalla de registro aquí
}
