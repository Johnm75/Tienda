package com.example.tienda.screens.products

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ProductsScreen() {
    Text(text = "Pantalla de Productos")
    // Agrega el resto de los componentes para la pantalla de productos aquí
}
