package com.example.tienda.screens.cart

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun CartScreen() {
    Text(text = "Pantalla de Carrito")
    // Agrega el resto de los componentes para la pantalla del carrito aquí
}
